Filesystem & Navigation

  help — list all commands

  pwd — print current directory

  ls — list files and folders

  cd <path> — change directory

  cd - — go to parent directory

  mkdir <folder> — create a folder

  touch <file> — create a file

  rm <file/folder> — delete a file or folder

  cat/view <file> — view file content

  cp <src> <dst> — copy file

  mv <src> <dst> — move/rename file

  stat <file> — show file size

  tree — list current directory structure

Network & System

  ping <host> — ping a host

  tracert <host> — trace route to a host

  curl <url> — send HTTP request

  nmap <host> — scan host ports

  ip — network interface info

  netstat — list network connections

  ipchange dhcp — renew IP via DHCP

Other

  echo <text> — print text

  clear — clear the console

  exit — exit Termium